<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN" "http://www.w3.org/MarkUp
/DTD/xhtml-rdfa-1.dtd">
<htmlxmlns="http://www.w3.org/1999/xhtml"
  xmlns:xsd ="http://www.w3.org/2001/XMLSchema#"
  xmlns:dcterms="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"  
  xmlns:vcard="http://www.w3.org/2006/vcard/ns#"
  xmlns:owl="http://www.w3.org/2002/07/owl#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">

<head>
<title>Music Score Ontology</title>
</head>

<body>

<h1>Music Score Ontology of Sample Data</h1>

<h2>Below is the tabular sample data </h2>

<table border=1>
<tr>
<th>Music Score</th>
<th>Format</th>
</tr>
<tr>
<td>Hallelujah</td>
<td>Piano Score</td>
</tr>
<tr>
<td>Hungarian</td>
<td>Vocal Score</td>
</tr>
<tr>
<td>Here Comes my Wife</td>
<td>Choral Score</td>
</tr>
<tr>
</tr>
</table>

<h2>Triple Model Table</h2>

<table border=1>
<tr>
<th>Subject</th>
<th>Predicate</th>
<th>Object</th>
</tr>
<tr>
<td>Music Score</td>
<td>has</td>
<td>Title</td>
</tr>
<tr>
<td>Music Score</td>
<td>has</td>
<td>Format</td>
</tr>
<tr>
<td>Title</td>
<td>type</td>
<td>Hallelujah</td>
</tr>
<tr>
<td>Title</td>
<td>type</td>
<td>Hungarian</td>
</tr>
<tr>
<td>Title</td>
<td>type</td>
<td>Here Comes my Wife</td>
</tr>
<tr>
<td>Format</td>
<td>type</td>
<td>Piano Score</td>
</tr>
<tr>
<td>Format</td>
<td>type</td>
<td>Vocal Score</td>
</tr>
<tr>
<td>Format</td>
<td>type</td>
<td>Choral Score</td>
</tr>
<tr>
<td>Hallelujah</td>
<td>has</td>
<td>Piano Score</td>
</tr>
<tr>
<td>Hungarian</td>
<td>has</td>
<td>Vocal Score</td>
</tr>
<tr>
<td>Here Comes my Wife</td>
<td>has</td>
<td>Choral Score</td>
</tr>
<tr>
</tr>
</table>

<h2>After loading the Music Score Ontology RDF to my data store,</h2>

<em>The Arc2 application can output the specific triple store for the subjects, predicates and objects as shown below:</em>


<?php

print "<em>Running PHP code...</em>";

print "<br>";
print "<br>";


include_once(dirname(__FILE__).'/config.php');

/* store instantiation */

$store = ARC2::getStore($arc_config);

if (!$store->isSetUp()) {
  $store->setUp(); /* create MySQL tables */
}

/* LOAD will call the Web reader, which will call the
format detector, which in turn triggers the inclusion of an
appropriate parser, etc. until the triples end up in the store. */

$store->query('LOAD <http://localhost/arc2-starter-pack/rdf.rdf>');

$result2 = $store->query("SELECT DISTINCT ?subject WHERE { ?subject ?property ?object . }");
$rows = $result2["result"]["rows"];
if ($rows) {
    print "<table border='1'>\n";
    print "<tr><th>Subjects currently in use in the triple store</th></tr>\n";

    foreach ($rows as $row) {
        $item = $row["subject"];
        if (strpos($item, "http://www.w3.org/1999/02/22-rdf-syntax-ns#_") !== 0) {
            print "<tr><td>" . htmlspecialchars($item) . "</td></tr>\n";
        }
    }

    print "</table>\n";
} else {
    print "<strong>The ARC2 triple store is currently empty.\n";
    print "Please load some data first.</strong>";
}

print "<br>";
print "<br>";
print "<hr>";

$result = $store->query("SELECT DISTINCT ?property WHERE { ?subject ?property ?object . }");
$rows = $result["result"]["rows"];

if ($rows) {
    print "<table border='1'>\n";
    print "<tr><th>Properties currently in use in the triple store</th></tr>\n";

    foreach ($rows as $row) {
        $item = $row["property"];
        if (strpos($item, "http://www.w3.org/1999/02/22-rdf-syntax-ns#_") !== 0) {
            print "<tr><td>" . htmlspecialchars($item) . "</td></tr>\n";
        }
    }

    print "</table>\n";
} else {
    print "<strong>The ARC2 triple store is currently empty.\n";
    print "Please load some data first.</strong>";
}

print "<br>";
print "<br>";
print "<hr>";

$result3 = $store->query("SELECT DISTINCT ?object WHERE { ?subject ?property ?object . }");
$rows = $result3["result"]["rows"];

if ($rows) {
    print "<table border='1'>\n";
    print "<tr><th>Objects currently in use in the triple store</th></tr>\n";

    foreach ($rows as $row) {
        $item = $row["object"];
        if (strpos($item, "http://www.w3.org/1999/02/22-rdf-syntax-ns#_") !== 0) {
            print "<tr><td>" . htmlspecialchars($item) . "</td></tr>\n";
        }
    }

    print "</table>\n";
} else {
    print "<strong>The ARC2 triple store is currently empty.\n";
    print "Please load some data first.</strong>";
}
?>
</body>
</html>
